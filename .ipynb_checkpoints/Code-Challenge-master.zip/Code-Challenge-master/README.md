Data Engineering - Coding Challenge
===========================================================

Jose Portilla Submission for Coding Challenge






